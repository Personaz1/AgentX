# NeuroRAT C2 Framework - Установочный пакет

## Установка на сервер

1. Загрузите архив на сервер
2. Распакуйте: `tar -xzf neurorat_installer.tar.gz`
3. Запустите: `sudo ./setup.sh`

## Особенности

- Работает без Docker, подходит для слабых серверов
- Автоматическое определение IP сервера
- Автоматическая настройка зонда на IP сервера
- Создание билдов зонда через `build_zond`

## Требования

- Ubuntu 18.04 или выше
- Python 3.6+

## Управление

- Просмотр логов: `journalctl -u neurorat.service -f`
- Перезапуск сервера: `systemctl restart neurorat.service`
- Остановка сервера: `systemctl stop neurorat.service`
- Создание билда: `build_zond`
